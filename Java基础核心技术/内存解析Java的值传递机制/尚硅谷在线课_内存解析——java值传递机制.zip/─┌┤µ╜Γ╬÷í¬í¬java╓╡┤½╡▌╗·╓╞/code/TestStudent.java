package com.atguigu.java;

public class TestStudent {
	public static void main(String[] args) {
		Student s1 = new Student();
		System.out.println(s1.toString());
		//s1 = null;
		s1.setName("��÷÷");
		System.out.println(s1.getName());
	}
}

class Person{
	private String name;
	private int age;
	
	public Person(){
		super();
		System.out.println("Person!!!!");
	}
	public Person(String name,int age){
		this.name = name;
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + "]";
	}
	
}
class Student extends Person{
	String school;
	
	public Student(){
		super();
	}
	public Student(String name,int age,String school){
		super(name,age);
		this.school = school;
	}
	@Override
	public String toString() {
		return "Student [school=" + school + ", name=" + getName()
				+ ", age=" + getAge() + "]";
	}
	
}