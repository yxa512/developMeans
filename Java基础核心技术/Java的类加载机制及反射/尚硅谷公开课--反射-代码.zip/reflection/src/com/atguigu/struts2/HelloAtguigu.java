package com.atguigu.struts2;

public class HelloAtguigu {
	
	public String helloWorld(){
		System.out.println("helloWorld...");
		return "success";
	}
	
	public String test(){
		System.out.println("^^^test...");
		return "success";
	}
	
	public HelloAtguigu(int i) {
		System.out.println("HelloAtguigu's Constructor...");
	}
	
}
