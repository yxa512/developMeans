package com.atguigu.java;

import java.io.IOException;

public class Person {
	private int age;
	String name;
	protected double weight;
	public boolean ismale;
	public Person(){
		
	}
	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public boolean getIsmale() {
		return ismale;
	}

	public void setIsmale(boolean ismale) {
		this.ismale = ismale;
	}

	//�ڱ����е�����������
	private void info(){
		System.out.println(this.age);
	}
	private void info(String n){
		System.out.println(this.age);
	}
	protected String show() throws IOException{
		return null;
	}
	@Override
	public String toString() {
		return "Person [age=" + age + ", name=" + name + ", weight=" + weight
				+ ", ismale=" + ismale + "]";
	}
	
}
