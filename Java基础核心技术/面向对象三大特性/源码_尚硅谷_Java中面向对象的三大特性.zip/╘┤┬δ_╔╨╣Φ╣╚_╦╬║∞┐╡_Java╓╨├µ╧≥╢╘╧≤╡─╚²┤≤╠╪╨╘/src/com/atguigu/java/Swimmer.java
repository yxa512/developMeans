package com.atguigu.java;

public class Swimmer {

}
