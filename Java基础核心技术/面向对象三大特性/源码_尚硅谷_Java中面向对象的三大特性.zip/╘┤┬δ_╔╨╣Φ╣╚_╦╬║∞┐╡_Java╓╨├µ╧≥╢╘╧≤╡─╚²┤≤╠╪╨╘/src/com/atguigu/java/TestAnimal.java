package com.atguigu.java;

public class TestAnimal {
	public static void main(String[] args) {
		Animal a = new Animal();
		a.setLegs(4);
		//a.legs = 12;
		a.setEyeColor("red");
		System.out.println(a.getLegs());
		//System.out.println(a);
	}
	
}
class Animal{
	private int legs;
	private String eyeColor;
	@Override
	public String toString() {
		return "Animal [legs=" + legs + ", eyeColor=" + eyeColor + "]";
	}
	//����legs��getter��setter����
	public void setLegs(int legs){
		if(legs == 2 || legs == 4 || legs == 8){
			this.legs = legs;
		}else{
			System.out.println("�����legs���Ϸ������������룡");
		}
	}
	public int getLegs(){
		return this.legs;
	}
	public void setEyeColor(String eyeColor){
		this.eyeColor = eyeColor;
	}
	
}