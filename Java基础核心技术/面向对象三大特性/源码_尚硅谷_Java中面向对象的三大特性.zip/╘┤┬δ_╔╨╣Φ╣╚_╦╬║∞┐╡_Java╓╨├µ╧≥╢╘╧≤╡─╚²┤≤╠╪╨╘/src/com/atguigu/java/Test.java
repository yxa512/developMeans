package com.atguigu.java;

public class Test {
	public static void main(String[] args) {
		int[] i= new int[4];
		System.out.println(i[0]);
		Person p = new Person();
		
	}
}
