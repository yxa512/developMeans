package com.atguigu.java1;
import com.atguigu.java.Person;

public class Teacher extends Person{
	public static void main(String[] args) {
		//Person p = new Person();
		Teacher t = new Teacher();
		//t.weight
	}
}
