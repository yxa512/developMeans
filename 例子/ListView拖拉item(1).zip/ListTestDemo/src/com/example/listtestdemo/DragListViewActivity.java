package com.example.listtestdemo;

import java.util.ArrayList;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

public class DragListViewActivity extends Activity {

	private DragListView dListView;
	private DragListAdapter dAdapter;
	private ArrayList<String> title;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_list);
		
		initData();
		dListView = (DragListView)findViewById(R.id.dlv);
		dAdapter = new DragListAdapter(this, title);
		dListView.setAdapter(dAdapter);
	}
	
	public void initData(){
		title = new ArrayList<String>();
		for(int i=0;i<10;i++){
			title.add("index = "+i);
		}
	}
}
