package com.devtf.belial.camera;


public final class Constants {

    public static final int REQUEST_CROP = 1010;
}
