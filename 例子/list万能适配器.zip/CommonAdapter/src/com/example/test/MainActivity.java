package com.example.test;

import java.util.ArrayList;
import java.util.List;

import com.example.commonadapter.CommonAdapter;
import com.example.commonadapter.R;
import com.example.commonadapter.R.id;
import com.example.commonadapter.R.layout;
import com.example.commonadapter.R.menu;
import com.example.commonadapter.ViewHolder;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.display.FadeInBitmapDisplayer;
import com.nostra13.universalimageloader.core.display.RoundedBitmapDisplayer;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends Activity {

	private ListView listView;
	private List<NewsInfo> listData;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		initView();
		
	}

	private void initView() {
		// TODO Auto-generated method stub
		listView = (ListView)findViewById(R.id.listview);
		createData();
		listView.setAdapter(new CommonAdapter<NewsInfo>(this,listData,R.layout.news_item) {

			@Override
			public void convert(ViewHolder holder, final NewsInfo t) {
				// TODO Auto-generated method stub
				holder.setImageResource(R.id.image, t.getImage())
					  .setText(R.id.title, t.getTitle())
					  .setText(R.id.context, t.getContent())
					  .setText(R.id.date, t.getDate());
				
				holder.setOnClickListener(R.id.title, new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						Toast.makeText(MainActivity.this, t.getTitle(), Toast.LENGTH_SHORT).show();
					}
				});
			}
		});
	}

	private void createData() {
		// TODO Auto-generated method stub
		listData = new ArrayList<NewsInfo>();
		
		for(int i=1;i<=10;i++){
			NewsInfo info = new NewsInfo();
			info.setTitle("title id "+i);
			info.setContent("this news content : "+i);
			//info.setImage("http://preview.quanjing.com/ibrf004/ibxreh00833076.jpg");
			info.setImage("http://a2.att.hudong.com/18/66/01300533952232133398666037401.jpg");
			info.setDate("11-8 14:2"+i);
			listData.add(info);
		}
		
	}
	
	

}
