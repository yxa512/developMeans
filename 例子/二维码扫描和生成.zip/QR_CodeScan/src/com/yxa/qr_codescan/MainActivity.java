package com.yxa.qr_codescan;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Calendar;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.FocusFinder;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.WriterException;
import com.yxa.bitmap.ImageCompression;
import com.yxa.scan.EncodingHandler;
import com.yxa.scan.MipcaActivityCapture;

public class MainActivity extends Activity implements OnClickListener{

	private final static int SCANNIN_GREQUEST_CODE = 1;
	private EditText et_qr_code;
	private ImageView iv_code_bitmap;
	
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		((Button)findViewById(R.id.button_back)).setVisibility(View.INVISIBLE);
		((TextView)findViewById(R.id.textview_title)).setText(getResources().getString(R.string.title));
		
		et_qr_code = (EditText)findViewById(R.id.qr_code);
		iv_code_bitmap = (ImageView)findViewById(R.id.iv_code_bitmap);
		iv_code_bitmap.setOnLongClickListener(new OnLongClickListener() {
			public boolean onLongClick(View arg0) {
				if(iv_code_bitmap.getDrawable() == null) return false;
				Dialog dialog = new AlertDialog.Builder(MainActivity.this)
						.setTitle("��ʾ")
						.setMessage("�Ƿ�ͼƬ�洢���ֻ��У�")
						.setPositiveButton("��", new DialogInterface.OnClickListener(){
							public void onClick(DialogInterface arg0, int arg1) {  
								if("mounted".equals(Environment.getExternalStorageState())){
									saveBitmap();
								}else{
									Toast.makeText(MainActivity.this, "����洢��", 300).show();
								}
							}})
						.setNegativeButton("��", null)
						.create();
				dialog.show();
				return false;
			}
		});
		
		((Button)findViewById(R.id.bt_scan)).setOnClickListener(this);
		((Button)findViewById(R.id.bt_create)).setOnClickListener(this);
	}

	@Override
	public void onClick(View arg0) {
		switch (arg0.getId()) {
		case R.id.bt_scan:
			Intent intent = new Intent();
			intent.setClass(MainActivity.this, MipcaActivityCapture.class);
			intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			startActivityForResult(intent, SCANNIN_GREQUEST_CODE);
			break;
		case R.id.bt_create:
			String contentString = et_qr_code.getText().toString();
			if (!contentString.equals("")) {
				//�����ַ������ɶ�ά��ͼƬ����ʾ�ڽ����ϣ��ڶ�������ΪͼƬ�Ĵ�С��350*350��
				Bitmap qrCodeBitmap;
				try {
					qrCodeBitmap = EncodingHandler.createQRCode(contentString, 350);
					iv_code_bitmap.setImageBitmap(qrCodeBitmap);
				} catch (WriterException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}else {
				et_qr_code.setError("���ݲ�Ϊ��");
			}
		default:
			break;
		}
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
		super.onActivityResult(requestCode, resultCode, intent);
		switch (requestCode) {
		case SCANNIN_GREQUEST_CODE:
			if(resultCode == RESULT_OK){
				Bundle bundle = intent.getExtras();
				et_qr_code.setText(bundle.getString("result"));
				iv_code_bitmap.setImageBitmap((Bitmap)intent.getParcelableExtra("bitmap"));
			}
			break;

		default:
			break;
		}
	}
	
	private void saveBitmap() {
		File rootFolder = new File(Environment
				.getExternalStorageDirectory().getAbsolutePath()
				+File.separator+"DCIM"+File.separator);
		if (!rootFolder.exists()) {
			try {
				rootFolder.mkdir();
			} catch (SecurityException se) {
			}
		}
		
		final String fileName = rootFolder.getAbsoluteFile() + File.separator
				+ getFileNameWithTime();

		BitmapDrawable drawable = (BitmapDrawable)iv_code_bitmap.getDrawable();
		Bitmap bitmap = drawable.getBitmap();
		
		// ���Ϊ�ջ��Ѿ��������ˣ����ٴ���
		if(null == bitmap || bitmap.isRecycled()){
			return ;
		}
		
		// bitmap����ѹ��
		Bitmap frame = ImageCompression.getInstance().compressImage(bitmap,50);
		
		boolean bErr = false;
		FileOutputStream fos = null;

		try {
			fos = new FileOutputStream(fileName, false);
			bitmap.compress(Bitmap.CompressFormat.JPEG, 90, fos);
			fos.flush();
			fos.close();
			Toast.makeText(MainActivity.this, fileName, 700).show();
		} catch (Exception e) {
			bErr = true;
			System.out.println("saveImage(.): " + e.getMessage());
		} finally {
			if (bErr) {
				if (fos != null) {
					try {
						fos.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		}
		
		if (!bitmap.isRecycled() && null != bitmap) {
			bitmap = null;
		}
	}

	// filename: such as,M20101023_181010.jpg
		private static String getFileNameWithTime() {

			Calendar c = Calendar.getInstance();
			int mYear = c.get(Calendar.YEAR);
			int mMonth = c.get(Calendar.MONTH) + 1;
			int mDay = c.get(Calendar.DAY_OF_MONTH);
			int mHour = c.get(Calendar.HOUR_OF_DAY);
			int mMinute = c.get(Calendar.MINUTE);
			int mSec = c.get(Calendar.SECOND);

			StringBuffer sb = new StringBuffer();
			sb.append("IMG_");
			sb.append(mYear);
			if (mMonth < 10)
				sb.append('0');
			sb.append(mMonth);
			if (mDay < 10)
				sb.append('0');
			sb.append(mDay);
			sb.append('_');
			if (mHour < 10)
				sb.append('0');
			sb.append(mHour);
			if (mMinute < 10)
				sb.append('0');
			sb.append(mMinute);
			if (mSec < 10)
				sb.append('0');
			sb.append(mSec);
			sb.append(".jpg");

			return sb.toString();
		}
	
}
