package com.filter.yangsh.androidandh5demo;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by yangsh on 2017/4/5.
 */
public class H5WebView extends Activity {

    WebView webView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_h5_webview);
        initWebView();
    }

    private void initWebView() {
        try {
            webView = new WebView(this);

            // 支持js调用
            WebSettings settings = webView.getSettings();
            settings.setJavaScriptEnabled(true);
            settings.setBuiltInZoomControls(true);
            settings.setCacheMode(WebSettings.LOAD_NO_CACHE);

            // 自定义浏览器
            webView.setWebViewClient(new WebViewClient());

            // 辅助WebView处理Javascript的对话框，网站图标，网站title，加载进度等
            webView.setWebChromeClient(new ChromeClient());

            // 定义android接口
            webView.addJavascriptInterface(new AndroidAndJSInterface(), "Android");

            // 加载本地H5(注意格式)  file:///android_asset/H5.html
            // http://lzmhyy.lz-qs.com:8080/lzmh_analyse_api/resource/native_js/demo.html
            webView.loadUrl("file:///android_asset/H5.html");

            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    // 后续调用
                    String tip = "5s后调用";
                    webView.loadUrl("javascript:sign(" + "'" + tip + "'" + ")");
                }
            },5000);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private class ChromeClient extends WebChromeClient {
        @Override
        public void onProgressChanged(WebView view, int newProgress) {
            if (100 == newProgress) {
                sendSignToJs();
            }
            super.onProgressChanged(view, newProgress);
        }
    }

    /**
     * 向js发送签名
     */
    private void sendSignToJs() {
        String sign = sign();

        webView.loadUrl("javascript:sign(" + "'" + sign + "'" + ")");
        setContentView(webView);
    }

    /**
     * 刷新签名
     */
    private String sign() {
        // ...

        return "iamissign";
    }

    private static final int TYPE_CONTROL_TYPE_1 = 1;    // 传递参数
    private static final int TYPE_CONTROL_TYPE_2 = 2;

    class AndroidAndJSInterface {

        @JavascriptInterface
        public void control(int type) {
            switch (type) {
                case TYPE_CONTROL_TYPE_1:
                    display("我被叼啦");
                    break;
                case TYPE_CONTROL_TYPE_2:
                    display("我也被叼啦");
                    break;
                default:
                    break;
            }
        }

        @JavascriptInterface
        public String sign() {
            return "23423434";
        }

//        @JavascriptInterface
//        public String sign(){
//
//            String sign = "lisi";
//            String ids = "123,42,34";
//            String url = "[{\"sign\":\""+ sign +"\", \"city_ids\":\"" + ids + "\"}]";
//
//            JSONArray arr = new JSONArray();
//            JSONObject obj = new JSONObject();
//            try {
//                obj.put("sign",sign);
//                obj.put("city_ids",ids);
//                arr.put(obj);
//            } catch (JSONException e) {
//                e.printStackTrace();
//            }
//
//            // "[{\"sign\":\"阿福\", \"city_ids\":\"12222\"}]"
//
//            return arr.toString();
//        }

        @JavascriptInterface
        public void call(String phone) {

//            startActivity(new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + phone));
        }

        @JavascriptInterface
        public void video(String video) {


        }
    }

    private void display(String str) {
        Toast.makeText(H5WebView.this, str, Toast.LENGTH_SHORT).show();
    }
}
