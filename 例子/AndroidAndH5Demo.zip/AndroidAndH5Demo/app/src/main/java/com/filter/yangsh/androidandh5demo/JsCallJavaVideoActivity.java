package com.filter.yangsh.androidandh5demo;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class JsCallJavaVideoActivity extends Activity {

    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_js_call_java_video);
        webView = (WebView) findViewById(R.id.webview);
        WebSettings webSettings = webView.getSettings();

        //设置支持javascript(js)
        webSettings.setJavaScriptEnabled(true);

        //不调用系统浏览器-自定义浏览器
        webView.setWebViewClient(new WebViewClient());

        //加载网络的网页-本地的网页
//        webView.loadUrl("http://www.atguigu.com/teacher.shtml");

        //添加JavascriptInterface
        //以后js通过Android 字段调用AndroidAndJsInterface 中的任何方法
        webView.addJavascriptInterface(new AndroidAndJsInterface(),"android");
        //加载本地的html页面
        webView.loadUrl("file:///android_asset/RealNetJSCallJavaActivity.htm");

//        setContentView(webView);

    }


    class AndroidAndJsInterface{
        /**
         * 将会被js调用
         */
        @JavascriptInterface
        public void playVideo(int id, String videoUrl, String title){


            //1.把所有的播放调起来,并且播放
            Intent intent = new Intent();
            intent.setDataAndType(Uri.parse(videoUrl),"video/*");
            startActivity(intent);
            Toast.makeText(JsCallJavaVideoActivity.this, "videoUrl=="+videoUrl, Toast.LENGTH_SHORT).show();
        }
    }
}
