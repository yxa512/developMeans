/** Automatically generated file. DO NOT MODIFY */
package com.zhy.zhy_slidemenu_demo02;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}