/** Automatically generated file. DO NOT MODIFY */
package com.zhy.zhy_slidemenu_demo03;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}