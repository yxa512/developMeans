/** Automatically generated file. DO NOT MODIFY */
package com.example.zhy_slidingmenu;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}