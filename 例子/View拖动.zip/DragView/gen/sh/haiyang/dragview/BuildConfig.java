/** Automatically generated file. DO NOT MODIFY */
package sh.haiyang.dragview;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}