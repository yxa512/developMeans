package com.example.zhy_horizontalscrollview;

import android.R.integer;
import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity
{

	private GridView gridView;
	private int[] mImgIds;
	private gridviewAdapter gAdapter;
	private ImageView imageView;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_main);
		initData();
		initView();

	}

	private void initData()
	{
		mImgIds = new int[] { R.drawable.a, R.drawable.b, R.drawable.c,
				R.drawable.d, R.drawable.e, R.drawable.f, R.drawable.g,
				R.drawable.h, R.drawable.l };
		
	}

	private void initView()
	{
		imageView = (ImageView)findViewById(R.id.id_content);
		
		gridView = (GridView)findViewById(R.id.gridview);
		int size = mImgIds.length;
        int length = 100;
        int spac = 6;
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        float density = dm.density;
        int gridviewWidth = (int)(length*density*size+spac*density*(size-1));
        int itemWidth = (int) (length * density);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                gridviewWidth, LinearLayout.LayoutParams.MATCH_PARENT);
        gridView.setLayoutParams(params); // ����GirdView���ֲ���,���򲼾ֵĹؼ�
        gridView.setColumnWidth(itemWidth); // �����б����
        gridView.setHorizontalSpacing((int)(spac*density)); // �����б���ˮƽ���
        gridView.setStretchMode(GridView.NO_STRETCH);
        gridView.setNumColumns(size); // ����������=�б�������

        gAdapter = new gridviewAdapter(this, mImgIds);
		gridView.setAdapter(gAdapter);
		gridView.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> arg0, View view, int position,long arg3) {
				imageView.setImageResource(mImgIds[position]);
				
			}
		});
	}
	
	class gridviewAdapter extends BaseAdapter{

		private Context context;
		private int[] imgs;
		
		public gridviewAdapter(Context context,int[] imgs){
			this.context = context;
			this.imgs = imgs;
		}
		
		@Override
		public int getCount() {
			return imgs.length;
		}

		@Override
		public Object getItem(int position) {
			return imgs[position];
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View view, ViewGroup arg2) {
			
			ViewHolder viewHolder = null;
			if(null == view){
				view = getLayoutInflater().inflate(R.layout.activity_index_gallery_item, null);
				viewHolder = new ViewHolder();
				viewHolder.imageView = (ImageView)view.findViewById(R.id.id_index_gallery_item_image);
				viewHolder.textView = (TextView)view.findViewById(R.id.id_index_gallery_item_text);
				view.setTag(viewHolder);
			}else{
				viewHolder = (ViewHolder)view.getTag();
			}
			
			viewHolder.imageView.setImageResource(imgs[position]);
			viewHolder.textView.setText("info "+(position+1));
			
			return view;
		}
		
		private class ViewHolder{
			ImageView imageView;
			TextView textView;
		}
		
	}

}
