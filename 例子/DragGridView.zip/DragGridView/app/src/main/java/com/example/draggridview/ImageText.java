package com.example.draggridview;

/**
 * Content
 * Created by yxa512 on 2016/7/8 0008.
 */
public class ImageText {
    private int img;
    private String text;

    public int getImg() {
        return img;
    }

    public void setImg(int img) {
        this.img = img;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
