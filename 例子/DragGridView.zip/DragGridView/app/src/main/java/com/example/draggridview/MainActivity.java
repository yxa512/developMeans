package com.example.draggridview;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;

import com.example.framework.DragGridView;

import java.util.ArrayList;
import java.util.List;

/**
 * @blog http://blog.csdn.net/xiaanming 
 * 
 * @author xiaanming
 *
 */
public class MainActivity extends Activity {
	private List<ImageText> data = new ArrayList<ImageText>();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		DragGridView mDragGridView = (DragGridView) findViewById(R.id.dragGridView);
		for (int i = 0; i < 5; i++) {
			ImageText imgT = new ImageText();
			imgT.setImg(R.drawable.com_tencent_open_notice_msg_icon_big);
			imgT.setText("拖拽 " + i);
			data.add(imgT);
		}
		
		final DragAdapter mDragAdapter = new DragAdapter(this, data);

		mDragGridView.setAdapter(mDragAdapter);
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		for(ImageText imgT:data){
			Log.i("yxa", "object = "+imgT.getText());
		}
	}
}
