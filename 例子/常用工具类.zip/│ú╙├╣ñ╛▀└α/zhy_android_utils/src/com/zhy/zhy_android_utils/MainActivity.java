package com.zhy.zhy_android_utils;

import java.util.Date;

import com.zhy.utils.AppUtils;
import com.zhy.utils.DateUtils;
import com.zhy.utils.HttpUtils;
import com.zhy.utils.HttpUtils.CallBack;
import com.zhy.utils.KeyBoardUtils;
import com.zhy.utils.L;
import com.zhy.utils.NetUtils;
import com.zhy.utils.SDCardUtils;
import com.zhy.utils.SPUtils;
import com.zhy.utils.ScreenUtils;
import com.zhy.utils.StringUtils;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import android.widget.EditText;
import android.widget.ImageView;

public class MainActivity extends Activity
{

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		L.i(StringUtils.toInt("156", 17));
		L.i(StringUtils.hexStringToByteArray("dwdadad484d5dq"));

	}

	

}
