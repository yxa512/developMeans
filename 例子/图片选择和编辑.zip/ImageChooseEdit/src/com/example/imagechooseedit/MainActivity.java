package com.example.imagechooseedit;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Bitmap.Config;
import android.graphics.PorterDuff.Mode;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;

public class MainActivity extends Activity {

	File file = new File(Environment.getExternalStorageDirectory()
			+ "/idoorimages", getPhotoFileName());
	ImageView imageView;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		imageView = (ImageView)findViewById(R.id.userimg);
		imageView.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				showDialogpaizhao();
				
			}
		});
	}
	
	// 提示对话框方法
		public void showDialogpaizhao() {
			new AlertDialog.Builder(this)
					.setTitle("头像设置")
					.setPositiveButton("拍照", new DialogInterface.OnClickListener() {

						@Override
						public void onClick(DialogInterface dialog, int which) {
							// TODO Auto-generated method stub
							dialog.dismiss();
							// 调用系统的拍照功能
							Intent intent = new Intent(
									MediaStore.ACTION_IMAGE_CAPTURE);
							// 指定调用相机拍照后照片的储存路径
							intent.putExtra(MediaStore.EXTRA_OUTPUT,
									Uri.fromFile(file));
							startActivityForResult(intent, 1);
						}
					})
					.setNegativeButton("相册", new DialogInterface.OnClickListener() {

						@Override
						public void onClick(DialogInterface dialog, int which) {
							// TODO Auto-generated method stub
							dialog.dismiss();
							Intent intent = new Intent(Intent.ACTION_PICK, null);
							intent.setDataAndType(
									MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
									"image/*");
							startActivityForResult(intent, 2);
						}
					}).show();
		}

		//对图片进行裁剪
		private void startPhotoZoom(Uri uri, int size) {
			Intent intent = new Intent("com.android.camera.action.CROP");
			intent.setDataAndType(uri, "image/*");
			// crop为true是设置在开启的intent中设置显示的view可以剪裁
			intent.putExtra("crop", "true");

			// aspectX aspectY 是宽高的比例
			intent.putExtra("aspectX", 1);
			intent.putExtra("aspectY", 1);

			// outputX,outputY 是剪裁图片的宽高
			intent.putExtra("outputX", size);
			intent.putExtra("outputY", size);
			intent.putExtra("return-data", true);

			startActivityForResult(intent, 3);
		}

		// 将进行剪裁后的图片显示到UI界面上
		private void setPicToView(Intent picdata) {
			Bundle bundle = picdata.getExtras();
			if (bundle != null) {
				Bitmap photo = bundle.getParcelable("data");
				saveBitmap(photo);
				photo = getRoundedCornerBitmap(photo, 2);
				imageView.setImageBitmap(photo);

			}
		}
		
		// 使用系统当前时间加以调整作为裁剪照片的名称
		private String getPhotoName() {
			Date date = new Date(System.currentTimeMillis());
			SimpleDateFormat dateFormat = new SimpleDateFormat("'IMG'_HHmmss");
			return dateFormat.format(date) + ".jpg";
		}

		// 使用系统当前日期加以调整作为照片的名称
		private String getPhotoFileName() {
			Date date = new Date(System.currentTimeMillis());
			SimpleDateFormat dateFormat = new SimpleDateFormat(
					"'IMG'_yyyyMMdd_HHmmss");
			return dateFormat.format(date) + ".jpg";
		}
		
		@Override
		protected void onActivityResult(int requestCode, int resultCode, Intent data) {
			// TODO 自动生成的方法存根
			super.onActivityResult(requestCode, resultCode, data);
			// Log.i("now", "requestCode" + requestCode + "   resultCode" +
			// resultCode);
			switch (requestCode) {
			case 1:// 当选择拍照时调用
				switch (resultCode) {
				case 0:
					break;
				case -1:
					new Handler().postDelayed(new Runnable() {
						public void run() {
							// TODO Auto-generated method stub
							startPhotoZoom(Uri.fromFile(file), 150);
						}
					}, 500);
					break;

				default:
					break;
				}
				break;
			case 2:// 当选择从本地获取图片时
				// 做非空判断，当我们觉得不满意想重新剪裁的时候便不会报异常，下同
				if (data != null)
					startPhotoZoom(data.getData(), 150);
				break;

			case 3:// 返回的结果
				if (data != null)
					setPicToView(data);
				System.out.println("data" + data);
				break;
			}
		}
		
		/** 保存方法 */
		public void saveBitmap(Bitmap photo) {
			File f = new File(
					Environment.getExternalStorageDirectory() + "/idoorimages",
					getPhotoName());
			if (f.exists()) {
				f.delete();
			}
			try {
				FileOutputStream out = new FileOutputStream(f);
				photo.compress(Bitmap.CompressFormat.PNG, 90, out);
				out.flush();
				out.close();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		
		/**
		 * 将图片截取为圆角图片
		 * 
		 * @param bitmap
		 *            原图片
		 * @param ratio
		 *            截取比例，如果是8，则圆角半径是宽高的1/8，如果是2，则是圆形图片
		 * @return 圆角矩形图片
		 */
		public static Bitmap getRoundedCornerBitmap(Bitmap bitmap, float ratio) {

			Bitmap output = Bitmap.createBitmap(bitmap.getWidth(),
					bitmap.getHeight(), Config.ARGB_8888);
			Canvas canvas = new Canvas(output);

			final Paint paint = new Paint();
			final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
			final RectF rectF = new RectF(rect);

			paint.setAntiAlias(true);
			canvas.drawARGB(0, 0, 0, 0);
			canvas.drawRoundRect(rectF, bitmap.getWidth() / ratio,
					bitmap.getHeight() / ratio, paint);

			paint.setXfermode(new PorterDuffXfermode(Mode.SRC_IN));
			canvas.drawBitmap(bitmap, rect, rect, paint);
			return output;
		}

}
