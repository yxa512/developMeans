/** Automatically generated file. DO NOT MODIFY */
package com.yxa.qr_codescan;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}