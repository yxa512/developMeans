package com.yxa.scan;

import java.util.Hashtable;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.text.TextUtils;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.ChecksumException;
import com.google.zxing.DecodeHintType;
import com.google.zxing.EncodeHintType;
import com.google.zxing.FormatException;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.NotFoundException;
import com.google.zxing.Result;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.common.HybridBinarizer;
import com.google.zxing.qrcode.QRCodeReader;
/**
 * @author Ryan Tang
 *	���ɶ�ά��
 */
public final class EncodingHandler {
	private static final int BLACK = 0xff000000;
	private static final int WHITE = 0xffffffff;
	
	/**
	 * ���ɶ�ά��
	 * @param str
	 * @param widthAndHeight
	 * @return
	 * @throws WriterException
	 */
	public static Bitmap createQRCode(String str,int widthAndHeight) throws WriterException {
		Hashtable<EncodeHintType, String> hints = new Hashtable<EncodeHintType, String>();  
        hints.put(EncodeHintType.CHARACTER_SET, "utf-8"); 
		BitMatrix matrix = new MultiFormatWriter().encode(str,
				BarcodeFormat.QR_CODE, widthAndHeight, widthAndHeight);
		int width = matrix.getWidth();
		int height = matrix.getHeight();
		int[] pixels = new int[width * height];
		
		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {
				//����洢ͼƬ��ʱ��һ�ź�����
				if (matrix.get(x, y)) { // ����Ϣ�������ص�ɺ�ɫ
					pixels[y * width + x] = BLACK;
				} else { // ����Ϣ�������ص�Ϊ��ɫ
					pixels[y * width + x] = WHITE;
				}
				/*Դ����
				if (matrix.get(x, y)) {
					pixels[y * width + x] = BLACK;
				}*/
			}
		}
		Bitmap bitmap = Bitmap.createBitmap(width, height,
				Bitmap.Config.ARGB_8888);
		bitmap.setPixels(pixels, 0, width, 0, 0, width, height);
		return bitmap;
	}
	
	 /**
     * �ڶ�ά���м�����Logoͼ��
     */
    public static Bitmap  addLogo(Bitmap src, Bitmap logo) {
        if (src == null) {
            return null;
        }
 
        if (logo == null) {
            return src;
        }
 
        //��ȡͼƬ�Ŀ���
        int srcWidth = src.getWidth();
        int srcHeight = src.getHeight();
        int logoWidth = logo.getWidth();
        int logoHeight = logo.getHeight();
 
        if (srcWidth == 0 || srcHeight == 0) {
            return null;
        }
 
        if (logoWidth == 0 || logoHeight == 0) {
            return src;
        }
 
        //logo��СΪ��ά�������С��1/5
        float scaleFactor = srcWidth * 1.0f / 7 / logoWidth;
        Bitmap bitmap = Bitmap.createBitmap(srcWidth, srcHeight, Bitmap.Config.ARGB_8888);
        try {
            Canvas canvas = new Canvas(bitmap);
            canvas.drawBitmap(src, 0, 0, null);
            canvas.scale(scaleFactor, scaleFactor, srcWidth / 2, srcHeight / 2);
            canvas.drawBitmap(logo, (srcWidth - logoWidth) / 2, (srcHeight - logoHeight) / 2, null);
 
            canvas.save(Canvas.ALL_SAVE_FLAG);
            canvas.restore();
        } catch (Exception e) {
            bitmap = null;
            e.getStackTrace();
        }
 
        return bitmap;
    }
	
    /**
     * ɨ��ͼƬ
     * @param path
     * @return
     */
	public static Result scanningImage(String path) {  
        if (TextUtils.isEmpty(path)) {  
            return null;  
        }  
        // DecodeHintType ��EncodeHintType  
        Hashtable<DecodeHintType, String> hints = new Hashtable<DecodeHintType, String>();  
        hints.put(DecodeHintType.CHARACTER_SET, "utf-8"); // ���ö�ά�����ݵı���  
        BitmapFactory.Options options = new BitmapFactory.Options();  
        options.inJustDecodeBounds = true; // �Ȼ�ȡԭ��С  
        Bitmap scanBitmap = BitmapFactory.decodeFile(path, options);  
        options.inJustDecodeBounds = false; // ��ȡ�µĴ�С  
  
        int sampleSize = (int) (options.outHeight / (float) 200);  
  
        if (sampleSize <= 0)  
            sampleSize = 1;  
        options.inSampleSize = sampleSize;  
        scanBitmap = BitmapFactory.decodeFile(path, options);  
  
        RGBLuminanceSource source = new RGBLuminanceSource(scanBitmap);  
        BinaryBitmap bitmap1 = new BinaryBitmap(new HybridBinarizer(source));  
        QRCodeReader reader = new QRCodeReader();  
        try {  
  
            return reader.decode(bitmap1, hints);  
  
        } catch (NotFoundException e) {  
  
            e.printStackTrace();  
  
        } catch (ChecksumException e) {  
  
            e.printStackTrace();  
  
        } catch (FormatException e) {  
  
            e.printStackTrace();  
  
        }  
  
        return null;  
  
    } 
}
