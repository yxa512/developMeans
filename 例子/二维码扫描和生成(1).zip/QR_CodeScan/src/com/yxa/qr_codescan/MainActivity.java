package com.yxa.qr_codescan;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.Result;
import com.google.zxing.WriterException;
import com.yxa.scan.EncodingHandler;
import com.yxa.scan.MipcaActivityCapture;

public class MainActivity extends Activity implements OnClickListener{

	private final static int SCANNIN_GREQUEST_CODE = 1;
	private final static int REQUEST_CODE = 2;
	private EditText et_qr_code;
	private ImageView iv_code_bitmap;
	private String photo_path;
	
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		((Button)findViewById(R.id.button_back)).setVisibility(View.INVISIBLE);
		((TextView)findViewById(R.id.textview_title)).setText(getResources().getString(R.string.title));
		
		et_qr_code = (EditText)findViewById(R.id.qr_code);
		iv_code_bitmap = (ImageView)findViewById(R.id.iv_code_bitmap);
		iv_code_bitmap.setOnLongClickListener(new OnLongClickListener() {//����ͼƬ����ͼƬ
			public boolean onLongClick(View arg0) {
				if(iv_code_bitmap.getDrawable() == null) return false;
				Dialog dialog = new AlertDialog.Builder(MainActivity.this)
						.setTitle("��ʾ")
						.setMessage("�Ƿ�ͼƬ�洢���ֻ��У�")
						.setPositiveButton("��", new DialogInterface.OnClickListener(){
							public void onClick(DialogInterface arg0, int arg1) {  
								if("mounted".equals(Environment.getExternalStorageState())){//���洢��
									BitmapDrawable drawable = (BitmapDrawable)iv_code_bitmap.getDrawable();
									Utils.saveBitmap(drawable,handler);//����
								}else{
									handler.obtainMessage(1, "����洢��").sendToTarget();
								}
							}})
						.setNegativeButton("��", null)
						.create();
				dialog.show();
				return false;
			}
		});
		
		((Button)findViewById(R.id.bt_scan)).setOnClickListener(this);
		((Button)findViewById(R.id.bt_create)).setOnClickListener(this);
		((Button)findViewById(R.id.bt_local)).setOnClickListener(this);
	}

	@Override
	public void onClick(View arg0) {
		switch (arg0.getId()) {
		case R.id.bt_scan://ɨ���ά��
			Intent intent = new Intent();
			intent.setClass(MainActivity.this, MipcaActivityCapture.class);
			intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			startActivityForResult(intent, SCANNIN_GREQUEST_CODE);
			break;
		case R.id.bt_create://���ɶ�ά��
			String contentString = et_qr_code.getText().toString();
			if (!TextUtils.isEmpty(contentString)) {
				//�����ַ������ɶ�ά��ͼƬ����ʾ�ڽ����ϣ��ڶ�������ΪͼƬ�Ĵ�С��350*350��
				Bitmap qrCodeBitmap;
				try {
					qrCodeBitmap = EncodingHandler.createQRCode(contentString, 350);
					Bitmap logo = BitmapFactory.decodeResource(getResources(), R.drawable.ic_launcher);
					qrCodeBitmap = EncodingHandler.addLogo(qrCodeBitmap, logo);
					iv_code_bitmap.setImageBitmap(qrCodeBitmap);
				} catch (WriterException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}else {
				handler.obtainMessage(1, "���ݲ�Ϊ��").sendToTarget();
			}
			break;
		case R.id.bt_local://ɨ�豾�ض�ά��ͼƬ
			Intent innerIntent = new Intent(); // �������
		    if (Build.VERSION.SDK_INT < 19) {  
		        innerIntent.setAction(Intent.ACTION_GET_CONTENT);  
		    } else {  
		        innerIntent.setAction(Intent.ACTION_OPEN_DOCUMENT);  
		    }  
		  
		    innerIntent.setType("image/*");  
		  
		    Intent wrapperIntent = Intent.createChooser(innerIntent, "ѡ���ά��ͼƬ");  
		  
		    MainActivity.this.startActivityForResult(wrapperIntent, REQUEST_CODE);  
			break;
		default:
			break;
		}
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
		super.onActivityResult(requestCode, resultCode, intent);
		switch (requestCode) {
		case SCANNIN_GREQUEST_CODE://��ά��ɨ��������
			if(resultCode == RESULT_OK){
				Bundle bundle = intent.getExtras();
				handler.obtainMessage(2, bundle.getString("result")).sendToTarget();
				iv_code_bitmap.setImageBitmap((Bitmap)intent.getParcelableExtra("bitmap"));
			}
			break;
		case REQUEST_CODE://ͼƬѡ��������
			if(resultCode == RESULT_OK){
				String[] proj = { MediaStore.Images.Media.DATA };  
                // ��ȡѡ��ͼƬ��·��  
                Cursor cursor = getContentResolver().query(intent.getData(),  
                        proj, null, null, null);  
                if (cursor.moveToFirst()) {  
  
                    int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
                    photo_path = cursor.getString(column_index);  
                    if (photo_path == null) {  
                        photo_path = Utils.getPath(getApplicationContext(),  
                        		intent.getData());  
                    }
                    Log.i("yxa", "photo_path = "+photo_path);  
  
                }  
  
                cursor.close();  
  
                new Thread(new Runnable() {  
  
                    @Override  
                    public void run() {  
  
                        Result result = EncodingHandler.scanningImage(photo_path);  
                        // String result = decode(photo_path);  
                        if (result == null) {  
                            handler.obtainMessage(1, "ͼƬ��ʽ����").sendToTarget();
                        } else {  
                            // ���ݷ���  
                            String recode = Utils.recode(result.toString());
                            handler.obtainMessage(2, recode).sendToTarget();
                           
                        }  
                    }  
                }).start();  
			}
			break;
		default:
			break;
		}
	}
	
	Handler handler = new Handler(){
		public void handleMessage(android.os.Message msg) {
			int code = msg.what;
			switch (code) {
			case 1:
				Toast.makeText(MainActivity.this, msg.obj.toString(), Toast.LENGTH_SHORT).show();
				break;
			case 2:
				et_qr_code.setText(msg.obj.toString());
				break;
			default:
				break;
			}
		};
	};
		
	
}
