package com.stevenhu.hu.dgt;

import java.util.ArrayList;

import android.app.Activity;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ListView;
import android.widget.TextView;

public class GestureListActivity extends Activity {

	private ArrayList<String> gesNames = new ArrayList<String>();//保存手写的名称集合  
	private ArrayList<Bitmap> gesPics = new ArrayList<Bitmap>();//保存转换为手写的图片的集合  
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		 setContentView(R.layout.list_activity);
		 
		 gesNames = (ArrayList<String>)getIntent().getExtras().get("name");
		 gesPics = (ArrayList<Bitmap>)getIntent().getExtras().get("pic");
		 ListView listView = (ListView)findViewById(R.id.listview);
		 ListViewAdapter adapter = new ListViewAdapter(this,gesNames,gesPics);
		 listView.setAdapter(adapter);
		 
		 ((TextView)findViewById(R.id.back)).setOnClickListener(new OnClickListener() {
			public void onClick(View arg0) {
				finish();
				
			}
		});
	}
	
}
