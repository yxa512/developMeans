package com.stevenhu.hu.dgt;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Set;

import android.R.drawable;
import android.app.Activity;
import android.content.Intent;
import android.gesture.Gesture;
import android.gesture.GestureLibraries;
import android.gesture.GestureLibrary;
import android.gesture.GestureOverlayView;
import android.gesture.GestureOverlayView.OnGesturePerformedListener;
import android.gesture.GestureOverlayView.OnGesturingListener;
import android.gesture.Prediction;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Environment;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SlidingDrawer;
import android.widget.SlidingDrawer.OnDrawerCloseListener;
import android.widget.SlidingDrawer.OnDrawerOpenListener;
import android.widget.TextView;
import android.widget.Toast;

public class DrawGestureTest extends Activity implements OnGesturePerformedListener
					,OnGesturingListener,OnClickListener{
	
	private GestureOverlayView mDrawGestureView;
	private Button bt_save,bt_clean,bt_add;
	private Gesture mGesture;
	private GestureLibrary lib;
	private TextView tv_add,tv_check;
	private EditText et_value;
	private LinearLayout ll_et_tv;
	private ArrayList<String> gesNames = new ArrayList<String>();//保存手写的名称集合  
	private ArrayList<Bitmap> gesPics = new ArrayList<Bitmap>();//保存转换为手写的图片的集合  
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        mDrawGestureView = (GestureOverlayView)findViewById(R.id.gesture);
        
        //设置手势可多笔画绘制，默认情况为单笔画绘制
        mDrawGestureView.setGestureStrokeType(GestureOverlayView.GESTURE_STROKE_TYPE_MULTIPLE);
        //设置手势的颜色(蓝色)
        mDrawGestureView.setGestureColor(gestureColor(R.color.gestureColor));
        //设置还没未能形成手势绘制是的颜色(红色)
        mDrawGestureView.setUncertainGestureColor(gestureColor(R.color.ungestureColor));
        //设置手势的粗细
        mDrawGestureView.setGestureStrokeWidth(4);
        /*手势绘制完成后淡出屏幕的时间间隔，即绘制完手指离开屏幕后相隔多长时间手势从屏幕上消失；
         * 可以理解为手势绘制完成手指离开屏幕后到调用onGesturePerformed的时间间隔
         * 默认值为420毫秒，这里设置为2秒
         */
        mDrawGestureView.setFadeOffset(2000);
        //绑定监听器
        mDrawGestureView.addOnGesturePerformedListener(this);
        mDrawGestureView.addOnGesturingListener(this);
        
        //保存图片的按钮
        bt_save = (Button)findViewById(R.id.save);
        bt_save.setOnClickListener(this);
        //清除笔记的按钮
        bt_clean = (Button)findViewById(R.id.clean);
        bt_clean.setOnClickListener(this);
        //打开添加手势
        bt_add = (Button)findViewById(R.id.add);
        bt_add.setOnClickListener(this);
        //添加手势
        tv_add = (TextView)findViewById(R.id.tv_add);
        tv_add.setOnClickListener(this);  
        //查看手势
        tv_check = (TextView)findViewById(R.id.tv_check);
        tv_check.setOnClickListener(this);
        //添加手势局部界面
        ll_et_tv = (LinearLayout)findViewById(R.id.ll_et_tv);
        //手势具体意思
        et_value = (EditText)findViewById(R.id.et_value);
     
        getExitGesture();
    }
    
    //手势绘制完成时调用
	@Override
	public void onGesturePerformed(GestureOverlayView overlay, Gesture gesture) 
	{
		// TODO Auto-generated method stub
		ArrayList predictions = lib.recognize(gesture);
        // We want at least one prediction  
        if (predictions.size() > 0) {  
            Prediction prediction = (Prediction) predictions.get(0);  
            // We want at least some confidence in the result  
            if (prediction.score > 2.0) {  //准确度20%
                // Show the spell  
                Toast.makeText(this, prediction.name, Toast.LENGTH_SHORT).show();  
            }  
        }  
	}
	
	private int gestureColor(int resId)
	{
		return getResources().getColor(resId);
	}

	//结束正在绘制手势时调用(手势绘制完成时一般是先调用它在调用onGesturePerformed)
	@Override
	public void onGesturingEnded(GestureOverlayView overlay) 
	{
		if(View.VISIBLE == bt_add.VISIBLE)
				mGesture = overlay.getGesture();
	}

	//正在绘制手势时调用
	@Override
	public void onGesturingStarted(GestureOverlayView overlay) 
	{
		mGesture = null;
	}

	@Override
	protected void onDestroy() 
	{
		// TODO Auto-generated method stub
		super.onDestroy();
		//移除绑定的监听器
		mDrawGestureView.removeOnGesturePerformedListener(this);
		mDrawGestureView.removeOnGesturingListener(this);
	}

	@Override
	public void onClick(View arg0) {
		switch (arg0.getId()) {
		case R.id.save://保存图片
			if(null != mGesture){
				Bitmap bitmap = mGesture.toBitmap(480, 750, 12, Color.BLUE);
				saveImage(bitmap);
			}
			
			break;
		case R.id.clean:
			mDrawGestureView.setFadeOffset(10);//清除前设置时间间隔缩小     
			mDrawGestureView.clear(true);      
			mDrawGestureView.setFadeOffset(3600000);//清楚后恢复时间间隔 
			break;
		case R.id.add:
			if(View.GONE == ll_et_tv.getVisibility()){
				ll_et_tv.setVisibility(View.VISIBLE);
				bt_save.setVisibility(View.VISIBLE);
				mDrawGestureView.setFadeOffset(10);//清除前设置时间间隔缩小     
	  			mDrawGestureView.clear(true);      
	  			mDrawGestureView.setFadeOffset(3600000);//清楚后恢复时间间隔 
			}else{
				ll_et_tv.setVisibility(View.GONE);
				bt_save.setVisibility(View.GONE);
				mDrawGestureView.setFadeOffset(10);//清除前设置时间间隔缩小     
	  			mDrawGestureView.clear(true);      
	  			mDrawGestureView.setFadeOffset(2000);//清楚后恢复时间间隔 
			}
			break;
		case R.id.tv_add:
			if(null != mGesture && !TextUtils.isEmpty(et_value.getText().toString())){
				saveGesture();
			}
			break;
		case R.id.tv_check:
		    getExitGesture();
		    Bundle bundle = new Bundle();
		    bundle.putStringArrayList("name", gesNames);
		    bundle.putSerializable("pic", gesPics);
		    Intent intent = new Intent(DrawGestureTest.this,GestureListActivity.class);
		    intent.putExtras(bundle);
		    startActivity(intent);
			break;
		default:
			break;
		}
		
	}
	
	/**
	 * 读取SD卡中的/sdcard/gestures里建立的手写，并显示在ListView中  
	 */
    public void getExitGesture() { 
    	if (!this.isExternalStorageWritable()) {
			Toast.makeText(this, "检查是否存在sd卡", Toast.LENGTH_SHORT).show();
			return;
		}
		/* 取得系统默认的GestureLibrary的文件路径 */  
	    String path = Environment
				.getExternalStorageDirectory().getAbsolutePath()+File.separator+"DCIM"
	    		+File.separator+"gestures"+File.separator;
        File f = new File(path);  
        lib = GestureLibraries.fromFile(f);
        gesNames.clear();  
        gesPics.clear();  
        if (f.exists()) {  
            if (!lib.load()) {  
                Toast.makeText(this, "加载失败！！",Toast.LENGTH_SHORT).show();  
            } else {  
                Object[] obj = lib.getGestureEntries().toArray();  
                for (int i = 0; i < obj.length; i++) {  
                    ArrayList<Gesture> al = lib.getGestures(obj[i].toString());  
                    for (int j = 0; j < al.size(); j++) {  
                        // 手写名称  
                        gesNames.add(obj[i].toString());  
                        Gesture gs = (Gesture) al.get(j);  
                        //将手写转成Bitmap图片  
                        gesPics.add(gs.toBitmap(50, 50, 12, Color.MAGENTA));  
                    }  
                }  
            }  
        } else {  
            Toast.makeText(this, "文件不存在！",Toast.LENGTH_SHORT).show();  
        }  
  
    }  
	
	/**
	 * 判断外存储区是否可写入
	 * 
	 * @return
	 */
	private boolean isExternalStorageWritable() {
		String state = Environment.getExternalStorageState();
		if (Environment.MEDIA_MOUNTED.equals(state)) {
			return true;
		}
		return false;
	}
	
	/**
	 * 把图片Bitmap对象存放到指定文件
	 * 
	 * @param bitmap
	 * @param filePath
	 * @throws  
	 * @throws IOException
	 */
	public void saveImage(Bitmap bitmap){
		if (!this.isExternalStorageWritable()) {
			Toast.makeText(this, "检查是否存在sd卡", Toast.LENGTH_SHORT).show();
			return;
		}
		
		File rootFolder = new File(Environment
				.getExternalStorageDirectory().getAbsolutePath()
				+File.separator+"DCIM"+File.separator);
		if (!rootFolder.exists()) {
			try {
				rootFolder.mkdir();
			} catch (SecurityException se) {
			}
		}
		
		final String fileName = 
				rootFolder.getAbsoluteFile() + File.separator + getFileNameWithTime();
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(fileName);
			Boolean isOk = bitmap.compress(Bitmap.CompressFormat.JPEG, 90, fos);
			if (isOk) {
				Toast.makeText(this, fileName, Toast.LENGTH_SHORT).show();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	/**
	 * 保存手势
	 */
	private void saveGesture(){
		if (!this.isExternalStorageWritable()) {
			Toast.makeText(this, "检查是否存在sd卡", Toast.LENGTH_SHORT).show();
			return;
		}
		/* 取得系统默认的GestureLibrary的文件路径 */  
	    String path = Environment
				.getExternalStorageDirectory().getAbsolutePath()+File.separator+"DCIM"
	    		+File.separator+"gestures"+File.separator;
	    File file = new File(path);
	    lib = GestureLibraries.fromFile(path);  
        
	    String gestureName = et_value.getText().toString().trim();  
     
      if (!file.exists()) {  
          /* 文件不存在就直接写入 */  
          lib.addGesture(gestureName, mGesture);  
          if (lib.save()) {  
              et_value.setText("");  
              mDrawGestureView.setFadeOffset(10);//清除前设置时间间隔缩小     
  			  mDrawGestureView.clear(true);      
  			  mDrawGestureView.setFadeOffset(3600000);//清楚后恢复时间间隔 
              Toast.makeText(this, "保存成功，路径为：" + path, Toast.LENGTH_SHORT).show();  
          } else {  
              Toast.makeText(this, "保存失败！", Toast.LENGTH_SHORT).show();  
          }  
      } else {  
          // 文件存在时，先读取已经存在的Gesture  
          if (lib.load()) {  
              /* 如果Library中存在相同名称，则先将其移除再写入 */  
              Set<String> set = lib.getGestureEntries();  
              if (set.contains(gestureName)) {  
                  ArrayList<Gesture> list = lib.getGestures(gestureName);  
                  for (int i = 0; i < list.size(); i++) {  
                      //删除手写数据  
                      lib.removeGesture(gestureName, list.get(i));  
                  }  
              }  
              //新增手写数据  
              lib.addGesture(gestureName, mGesture);  
              // 保存写入手写数据  
              if (lib.save()) {  
                  et_value.setText("");  
                  mDrawGestureView.setFadeOffset(10);//清除前设置时间间隔缩小     
      			  mDrawGestureView.clear(true);      
      			  mDrawGestureView.setFadeOffset(3600000);//清楚后恢复时间间隔   
                  Toast.makeText(this,  "保存成功，路径为：" + path, Toast.LENGTH_SHORT).show();  
              } else {  
                  Toast.makeText(this, "保存失败！", Toast.LENGTH_SHORT).show();  
              }  
          } else {  
              Toast.makeText(this, "加载失败！", Toast.LENGTH_SHORT).show();  
          }  
      }  
	}
	
	/**
	 * filename: such as,M20101023_181010.jpg
	 * @return
	 */
	private static String getFileNameWithTime() {

		Calendar c = Calendar.getInstance();
		int mYear = c.get(Calendar.YEAR);
		int mMonth = c.get(Calendar.MONTH) + 1;
		int mDay = c.get(Calendar.DAY_OF_MONTH);
		int mHour = c.get(Calendar.HOUR_OF_DAY);
		int mMinute = c.get(Calendar.MINUTE);
		int mSec = c.get(Calendar.SECOND);

		StringBuffer sb = new StringBuffer();
		sb.append("IMG_");
		sb.append(mYear);
		if (mMonth < 10)
			sb.append('0');
		sb.append(mMonth);
		if (mDay < 10)
			sb.append('0');
		sb.append(mDay);
		sb.append('_');
		if (mHour < 10)
			sb.append('0');
		sb.append(mHour);
		if (mMinute < 10)
			sb.append('0');
		sb.append(mMinute);
		if (mSec < 10)
			sb.append('0');
		sb.append(mSec);
		sb.append(".jpg");

		return sb.toString();
	}
	
}