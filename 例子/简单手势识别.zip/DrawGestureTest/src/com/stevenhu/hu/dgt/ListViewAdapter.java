package com.stevenhu.hu.dgt;

import java.util.List;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class ListViewAdapter extends BaseAdapter {

	private Context mContext;  
    private List<String> gesNames ;  
    private List<Bitmap> gesPics ;  
    
    public ListViewAdapter(Context mContext,List<String> gesNames,List<Bitmap> gesPics){
    	this.mContext = mContext;
    	this.gesNames = gesNames;
    	this.gesPics = gesPics;
    }
	
	@Override
	public int getCount() {
		return gesNames.size();
	}

	@Override
	public Object getItem(int arg0) {
		return gesNames.get(arg0);
	}

	@Override
	public long getItemId(int arg0) {
		return arg0;
	}

	@Override
	public View getView(int position, View view, ViewGroup viewGroup) {
		ViewHelper viewHelper = null;
		if(null == view){
			viewHelper = new ViewHelper();
			LayoutInflater layoutInflater = LayoutInflater.from(mContext);
			view = layoutInflater.inflate(R.layout.list_item, null);
			viewHelper.imageView = (ImageView)view.findViewById(R.id.img_id);
			viewHelper.textView = (TextView)view.findViewById(R.id.text_id);
			view.setTag(viewHelper);
		}else{
			viewHelper = (ViewHelper)view.getTag();
		}
		
		viewHelper.imageView.setImageBitmap(gesPics.get(position));
		viewHelper.textView.setText(gesNames.get(position));
		
		return view;
	}
	
	private class ViewHelper{
		ImageView imageView;
		TextView textView;
	}

}
