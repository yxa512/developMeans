/** Automatically generated file. DO NOT MODIFY */
package com.stevenhu.hu.dgt;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}