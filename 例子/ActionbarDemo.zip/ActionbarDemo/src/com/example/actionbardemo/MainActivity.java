package com.example.actionbardemo;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

import android.app.ActionBar;
import android.app.ActionBar.Tab;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MenuItem.OnActionExpandListener;
import android.view.ViewConfiguration;
import android.view.Window;
import android.widget.SearchView;
import android.widget.ShareActionProvider;
import android.widget.Toast;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		ActionBar actionBar = getActionBar();
		//actionBar.hide();//����
		actionBar.setDisplayHomeAsUpEnabled(true); //ͨ��Action Barͼ����е���
		
		setOverflowShowingAlways();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		
		//��ȡ����SearchView
		MenuItem searchItem = menu.findItem(R.id.action_search);
		SearchView searchView = (SearchView)searchItem.getActionView();
		searchItem.setOnActionExpandListener(new OnActionExpandListener() {
			public boolean onMenuItemActionExpand(MenuItem arg0) {
				Log.i("123", "1");
				return true;
			}
			
			@Override
			public boolean onMenuItemActionCollapse(MenuItem arg0) {
				Log.i("123", "2");
				return true;
			}
		});
		
		//��ȡ����ShareActionProvider
		MenuItem shareItem = menu.findItem(R.id.action_feed);  
	    ShareActionProvider provider = (ShareActionProvider) shareItem.getActionProvider();  
	    provider.setShareIntent(getDefaultIntent());  
		return true;
	}

	private Intent getDefaultIntent() {
		 Intent intent = new Intent(Intent.ACTION_SEND);  
		 intent.setType("image/*");  
		return intent;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home://Action Barͼ���¼�
			 finish();
			 return true;
		case R.id.action_search:
			Toast.makeText(MainActivity.this, item.getTitle(), Toast.LENGTH_SHORT).show();
			return true;
		case R.id.action_plus:
			Toast.makeText(MainActivity.this, item.getTitle(), Toast.LENGTH_SHORT).show();
			return true;
		case R.id.action_album:
			Toast.makeText(MainActivity.this, item.getTitle(), Toast.LENGTH_SHORT).show();
			return true;
		case R.id.action_collection:
			Toast.makeText(MainActivity.this, item.getTitle(), Toast.LENGTH_SHORT).show();
			return true;
		case R.id.action_card:
			Toast.makeText(MainActivity.this, item.getTitle(), Toast.LENGTH_SHORT).show();
			return true;
		case R.id.action_settings:
			Toast.makeText(MainActivity.this, item.getTitle(), Toast.LENGTH_SHORT).show();
			return true;
		case R.id.action_feed:
			Toast.makeText(MainActivity.this, item.getTitle(), Toast.LENGTH_SHORT).show();
			return true;
		default:
			return super.onOptionsItemSelected(item);
		}
		
	}
	

	/**
	 * ��overflow��չ����ʱ��ͻ�ص��������
	 * ʹAction��ť��Ӧ��ͼ��Ͷ�����ʾ����
	 */	
	@Override
	public boolean onMenuOpened(int featureId, Menu menu) {
		  if (featureId == Window.FEATURE_ACTION_BAR && menu != null) {  
		        if (menu.getClass().getSimpleName().equals("MenuBuilder")) {  
		            try {  
		                Method m = menu.getClass().getDeclaredMethod("setOptionalIconsVisible", Boolean.TYPE);  
		                m.setAccessible(true);  
		                m.invoke(menu, true);  
		            } catch (Exception e) {  
		            }  
		        }  
		    } 
		 return super.onMenuOpened(featureId, menu);
	}
	
	/**
	 * Overflow��ť��ʾ
	 */
	private void setOverflowShowingAlways() {  
	    try {  
	        ViewConfiguration config = ViewConfiguration.get(this);  
	        Field menuKeyField = ViewConfiguration.class.getDeclaredField("sHasPermanentMenuKey");  
	        menuKeyField.setAccessible(true);  
	        menuKeyField.setBoolean(config, false);  
	    } catch (Exception e) {  
	        e.printStackTrace();  
	    }  
	}
	
}
