package com.example.example;

import java.io.File;
import java.io.FilenameFilter;
import java.util.Timer;
import java.util.TimerTask;

import android.R.anim;
import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Filter;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		((StudentApplication)getApplication()).setAge(12);
		((StudentApplication)getApplication()).setName("小明");
		
		GlobalVariable.str = ",";
		
		((TextView)findViewById(R.id.tv)).setOnClickListener(new OnClickListener() {
			public void onClick(View arg0) {
				Manager.getInstance().print();
				String school = ((StudentApplication)getApplication()).school;
				int age = ((StudentApplication)getApplication()).getAge();
				String name = ((StudentApplication)getApplication()).getName();
				Log.i("MainActivity", name+"在"+school+"读书，现在"+age+"岁了");
				Log.i("MainActivity", GlobalVariable.print()+GlobalVariable.str+GlobalVariable.name);
				//ps:在view中，((StudentApplication)getContext().getApplicationContext())
			}
		});

	}
}
