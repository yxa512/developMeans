package com.example.example;

import android.util.Log;

public class GlobalVariable {
	
	public static String name = "小王";
	public static String str;
	
	public static String print(){
		return "你好";
	}
}
