package com.example.example;

import android.util.Log;

public class Manager {
	
	private static Manager manager;
	
	public static Manager getInstance(){
		if(null == manager){
			manager = new Manager();
			Log.i("Manager", "只打印一次");
		} 
			
		return manager;
	}
	
	public void print(){
		Log.i("Manager", "全局实例");
	}
}
