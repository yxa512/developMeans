package com.example.example;

import android.app.Application;
import android.util.Log;

public class StudentApplication extends Application {
	
	public String school = "希望小学";
	
	private int  age;
	private String name;
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public void onCreate() {
		Log.i("StudentApplication", "只在启动程序的时候创建");
		super.onCreate();
	}
	
	
}
