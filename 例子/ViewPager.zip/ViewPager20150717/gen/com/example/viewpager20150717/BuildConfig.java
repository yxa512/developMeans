/** Automatically generated file. DO NOT MODIFY */
package com.example.viewpager20150717;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}