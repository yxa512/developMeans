package com.example.viewpager20150717;

import java.util.ArrayList;
import android.app.Activity;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.PagerTabStrip;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.viewpager20150717.R;
/**
 * 
 * @Description: viewPager+fragment
 *
 * @author yxa512
 * @date 2015-7-17 ����4:35:50
 */

/**FragmentStatePagerAdapter �� FragmentPagerAdapter
��һ�� fragment״̬adapter -�ڵ�ǰֻ�����   ǰ1��fragment  ��ǰ fragment �� ��1�� fragment   �������� ���ʺϼ��ض�����

�ڶ��� FragmentPagerAdapter  - ȫ�����ڣ����Բ�̫�ʺϼ��� ���������� ��ͼƬʲô�ģ��������ڴ������*/

public class ViewPagerActivity3 extends FragmentActivity{

	 //������ж��ٸ� fragmentҳ��  
    static final int NUM_ITEMS = 3;  
    private MyAdapter mAdapter;  
    private ViewPager mPager;      
    private int nowPage;
    private ImageView image; 
    private int currIndex = 0;//��ǰҳ�����   
    private int bmpW;//����ͼƬ����   
    private int offset;//ͼƬ�ƶ���ƫ����   
    private int one;//��������ҳ���ƫ���� 
       
 
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.viewpager3);
 
        mAdapter = new MyAdapter(getSupportFragmentManager() );  
        mPager = (ViewPager)findViewById(R.id.viewpager);  
        mPager.setAdapter(mAdapter);  
		mPager.setCurrentItem(currIndex);
		mPager.setOnPageChangeListener(new OnPageChangeListener() {
			
			@Override
			public void onPageSelected(int position) {
				Animation animation = new TranslateAnimation(currIndex*one,position*one,0,0);//ƽ�ƶ���   
	            currIndex = position;  
	            animation.setFillAfter(true);//������ֹʱͣ�������һ֡����Ȼ��ص�û��ִ��ǰ��״̬   
	            animation.setDuration(200);//��������ʱ��0.2��   
	            image.startAnimation(animation);//����ImageView����ʾ������   
	            int i = currIndex + 1;  
	            Toast.makeText(ViewPagerActivity3.this, "��ѡ���˵�"+i+"��ҳ��", Toast.LENGTH_SHORT).show();  
				
			}
			
			@Override
			public void onPageScrolled(int arg0, float arg1, int arg2) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onPageScrollStateChanged(int arg0) {
				// TODO Auto-generated method stub
				
			}
		});
		
        InitImage();
	}
    
    /** 
     *  ��״̬�� ��ֻ����ǰ3������ �������٣�  ǰ1���� �м䣬 ��һ�� 
     */  
    public class MyAdapter extends   FragmentStatePagerAdapter {  
    	
    	public MyAdapter(FragmentManager fm) {  
              super(fm);  
        }  
  
        @Override  
        public int getCount() {  
            return NUM_ITEMS;  
        }  
  
        //�õ�ÿ��item  
        @Override  
        public Fragment getItem(int position) { 
            return ArrayFragment.newInstance(position);  
        }  
  
          
        // ��ʼ��ÿ��ҳ��ѡ��  
        @Override  
        public Object instantiateItem(ViewGroup arg0, int arg1) {  
            // TODO Auto-generated method stub  
            return super.instantiateItem(arg0, arg1);  
        }  
        
        //����
        @Override  
        public void destroyItem(ViewGroup container, int position, Object object) {  
            System.out.println( "position Destory " + position);  
            super.destroyItem(container, position, object);  
        }  
          
    }

    /** 
     * ���е�  ÿ��Fragment 
     */  
    public static class ArrayFragment extends Fragment {  
         
        int mNum;  
        static ArrayFragment newInstance(int num) {  
            ArrayFragment  array= new ArrayFragment();  
            Bundle args = new Bundle();  
            args.putInt("num", num);  
            array.setArguments(args);  
            return array;  
        }  
  
          
        @Override  
        public void onCreate(Bundle savedInstanceState) {  
            super.onCreate(savedInstanceState);  
            mNum = getArguments() != null ? getArguments().getInt("num") : 1;  
            System.out.println("mNum Fragment create ="+ mNum);  
        }  
  
          
        @Override  
        public View onCreateView(LayoutInflater inflater, ViewGroup container,  
                Bundle savedInstanceState) {  
             //���������ÿ�� fragment����ʾ�� View  
             View v = null;  
               
             if(mNum == 0){  
                  v = inflater.inflate(R.layout.tab1, container, false);  
             }else if(mNum == 1){  
                 v = inflater.inflate(R.layout.tab2, container, false);  
             }else  if(mNum == 2){  
                 v = inflater.inflate(R.layout.tab3, container, false);  
             }else if(mNum == 3){  
                 v = inflater.inflate(R.layout.tab4, container, false);  
             }else if(mNum == 4){  
                 v = inflater.inflate(R.layout.tab5, container, false);  
             }         
            return v;  
        }  
  
        @Override  
        public void onActivityCreated(Bundle savedInstanceState) {  
            super.onActivityCreated(savedInstanceState);     
        }  
          
        @Override  
        public void onDestroyView(){  
            super.onDestroyView();  
        }  
          
        @Override  
        public void onDestroy(){  
            super.onDestroy();   
        }     
    }  
    
    /* 
     * ��ʼ��ͼƬ��λ������ 
     */  
    public void InitImage(){  
        image = (ImageView)findViewById(R.id.tabview);
        bmpW = BitmapFactory.decodeResource(getResources(), R.drawable.cursor).getWidth();  
        DisplayMetrics dm = new DisplayMetrics();  
        getWindowManager().getDefaultDisplay().getMetrics(dm);  
        int screenW = dm.widthPixels;  
        Log.i("123", bmpW+" "+screenW+" "+offset);
        offset = (screenW/3 - bmpW)/2;  
        one = offset *2 +bmpW;
        //imgageview����ƽ�ƣ�ʹ�»���ƽ�Ƶ���ʼλ�ã�ƽ��һ��offset��   
        Matrix matrix = new Matrix();  
        matrix.postTranslate(offset, 0);  
        image.setImageMatrix(matrix);  
    }  

}
