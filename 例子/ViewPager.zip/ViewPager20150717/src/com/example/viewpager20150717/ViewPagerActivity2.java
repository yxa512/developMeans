package com.example.viewpager20150717;

import java.util.ArrayList;
import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.PagerTabStrip;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;

import com.example.viewpager20150717.R;
/**
 * 
 * @Description: �Զ��������
 *
 * @author yxa512
 * @date 2015-7-17 ����4:35:19
 */
public class ViewPagerActivity2 extends Activity implements OnClickListener{

	ViewPager pager = null;
    PagerTabStrip tabStrip = null;
    ArrayList<View> viewContainter = new ArrayList<View>();
    ArrayList<String> titleContainer = new ArrayList<String>();
    public String TAG = "tag";
    ScllorTabView mScllorTabView;
 
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.viewpager2);
 
        mScllorTabView = (ScllorTabView)findViewById(R.id.tabview);
        
        pager = (ViewPager) this.findViewById(R.id.viewpager);
        View view1 = LayoutInflater.from(this).inflate(R.layout.tab1, null);
        View view2 = LayoutInflater.from(this).inflate(R.layout.tab2, null);
        View view3 = LayoutInflater.from(this).inflate(R.layout.tab3, null);
      //viewpager��ʼ����view
        viewContainter.add(view1);
        viewContainter.add(view2);
        viewContainter.add(view3);
        
        //viewPager����������
        pager.setAdapter(new PagerAdapter() {
 
            //viewpager�е��������
            @Override
            public int getCount() {
                return viewContainter.size();
            }
          //�����л���ʱ�����ٵ�ǰ�����
            @Override
            public void destroyItem(ViewGroup container, int position,
                    Object object) {
                ((ViewPager) container).removeView(viewContainter.get(position));
            }
          //ÿ�λ�����ʱ�����ɵ����
            @Override
            public Object instantiateItem(ViewGroup container, int position) {
                ((ViewPager) container).addView(viewContainter.get(position));
                return viewContainter.get(position);
            }
 
            @Override
            public boolean isViewFromObject(View arg0, Object arg1) {
                return arg0 == arg1;
            }
 
            @Override
            public int getItemPosition(Object object) {
                return super.getItemPosition(object);
            }
 
            @Override
            public CharSequence getPageTitle(int position) {
                return titleContainer.get(position);
            }
        });
 
        findViewById(R.id.tv1).setOnClickListener(this);
        findViewById(R.id.tv2).setOnClickListener(this);
        findViewById(R.id.tv3).setOnClickListener(this);
        
        pager.setCurrentItem(1);//��viewPagerװ���������������Ч
        mScllorTabView.setTabNum(viewContainter.size());//��ǩ����
        mScllorTabView.setPaintColor(Color.RED);//��ǩ��ɫ
        mScllorTabView.setOffset(0, 1);//��ǩλ��
        
        
        //��viewPager���м���
        pager.setOnPageChangeListener(new OnPageChangeListener() {
            @Override
            public void onPageScrollStateChanged(int arg0) {
                Log.i(TAG, "--------changed:" + arg0);
            }
 
            @Override
            public void onPageScrolled(int arg0, float arg1, int arg2) {
                Log.i(TAG, "-------scrolled arg0:" + arg0);
                Log.i(TAG, "-------scrolled arg1:" + arg1);
                Log.i(TAG, "-------scrolled arg2:" + arg2);
                mScllorTabView.setOffset(arg0, arg1);
            }
 
            @Override
            public void onPageSelected(int arg0) {
                Log.i(TAG, "------selected:" + arg0);
            }
        });
 
    }

	@Override
	public void onClick(View arg0) {
		switch(arg0.getId()){
			case R.id.tv1:
		        pager.setCurrentItem(0);//��viewPagerװ���������������Ч
		        mScllorTabView.setOffset(0, 1);//��ǩλ��
		        break;
			case R.id.tv2:
		        pager.setCurrentItem(1);//��viewPagerװ���������������Ч
		        mScllorTabView.setOffset(1, 1);//��ǩλ��
			break;
			case R.id.tv3:
		        pager.setCurrentItem(2);//��viewPagerװ���������������Ч
		        mScllorTabView.setOffset(2, 1);//��ǩλ��
		        break;
		}
		
	}
}
