/** Automatically generated file. DO NOT MODIFY */
package com.example.progersssdialog;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}