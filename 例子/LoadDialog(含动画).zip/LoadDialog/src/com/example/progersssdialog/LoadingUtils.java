package com.example.progersssdialog;

import android.app.Activity;
import android.app.Dialog;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;


/**
 * 加载提示
 * @author Ace
 */
public class LoadingUtils {
	
	private static Dialog loading;

	public static void showLoading(Activity activity, boolean isCancelable) {
		if(null != loading){
			loading.dismiss();
		}
		if (null == loading) {
			loading = new Dialog(activity, R.style.CustomDialog);
			loading.setContentView(R.layout.loading);
			loading.setCancelable(isCancelable);
		}
		if (!activity.isFinishing() && !activity.isFinishing()) {
			loading.show();
		}
	}

	/**
	 * 显示等待进度�?
	 * 
	 * @param message
	 *            进度内容
	 */
	public static void showLoading(Activity activity, String message) {
		if(null != loading){
			loading.dismiss();
		}
		if (null == loading) {
			loading = new Dialog(activity, R.style.CustomDialog);
			View v = View.inflate(activity, R.layout.loading,null);
			if (!TextUtils.isEmpty(message)) {
				TextView contentView = (TextView) v.findViewById(R.id.Load_prompt);
				contentView.setVisibility(View.VISIBLE);
				contentView.setText(message);
			}
			loading.setContentView(v);
			loading.setCancelable(true);
		}
		if (!activity.isFinishing() && !activity.isFinishing()) {
			loading.show();
		}

	}

	/**
	 * 等待
	 * 
	 * @param activity
	 * @param message
	 * @param cancelable
	 */
	public static void showLoading(Activity activity, String message,boolean cancelable) {
		if(null != loading){
			loading.dismiss();
		}
		if (null == loading) {
			loading = new Dialog(activity, R.style.CustomDialog);
			View v = View.inflate(activity, R.layout.loading,
					null);
			if (!TextUtils.isEmpty(message)) {
				TextView contentView = (TextView) v.findViewById(R.id.Load_prompt);
				contentView.setVisibility(View.VISIBLE);
				contentView.setText(message);
			}
			loading.setContentView(v); 
			loading.setCancelable(true);
		}
		if (!activity.isFinishing() && !activity.isFinishing()) {
			loading.show();
		}
	}

	/**
	 * 取消显示进度�?
	 */
	public static void dissmissLoading() {
		if (null != loading && loading.isShowing()) {
			try {
				loading.dismiss();
				loading = null;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

}
