package com.example.progersssdialog;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

public class LoadDialog extends Dialog {
	
	private ImageView img;  
    private TextView txt;
    private Context context;
	
    public LoadDialog(Context context) {
		super(context,R.style.ActionSheetDialogStyle);
		this.context = context;
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.progress_dialog);
		
		 //��ͼƬ���Ӷ�̬Ч��  
        Animation anim=AnimationUtils.loadAnimation(context, R.anim.loading_dialog_progressbar);
        img = (ImageView)findViewById(R.id.progress_dialog_img);
        img.setAnimation(anim);
        
       // setCancelable(true);//���ProgressDialog����������ʱ��ProgressDialog����ر�
        setCanceledOnTouchOutside(false);//����ͬ�ϣ������Է��ؼ�ȡ��
	}
	
	          
}
