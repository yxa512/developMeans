package com.example.progersssdialog;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainActivity extends Activity implements OnClickListener{

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		((Button)findViewById(R.id.bt1)).setOnClickListener(this);
		((Button)findViewById(R.id.bt2)).setOnClickListener(this);
	}

	@Override
	public void onClick(View arg0) {
		switch (arg0.getId()) {
		case R.id.bt1:
			LoadingUtils.showLoading(MainActivity.this, null);
			break;
		case R.id.bt2:
			new LoadDialog(MainActivity.this).show();
			break;	
		default:
			break;
		}
		
	}

}
